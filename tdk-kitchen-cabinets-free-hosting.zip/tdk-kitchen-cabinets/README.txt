# T&D,K Kitchen Cabinets website

## Files
- `index.html` — the website homepage.
- `assets/` — image placeholders. Replace these with real project photos using the same filenames.
- `assets/video1.mp4` and `assets/video2.mp4` — optional videos you can add using these exact filenames.

## Before publishing
1. Replace the eight SVG placeholders in `assets/` with your own project photos. Keep the filenames:
   `photo1.svg`, `photo2.svg`, `photo4.svg`, `photo3.svg`, `photo5.svg`, `photo10.svg`, `photo11.svg`, `photo12.svg`.
   You can instead upload JPG images and edit the matching image filenames in `index.html`.
2. Add your video files as `assets/video1.mp4` and `assets/video2.mp4`. Then update the video placeholder blocks in `index.html` to use HTML video elements if desired.
3. Replace the generic Facebook, Instagram and TikTok links with the exact business profile URLs.
4. Confirm all claims, service areas, pricing/payment terms and reviews before adding them. This starter version avoids publishing unverified ratings, job counts and testimonials.

## Free publishing with GitHub Pages (iPhone)
1. Sign in or create an account at https://github.com.
2. Create a **new public repository** named `tdk-kitchen-cabinets` (you can use another name).
3. Open the repository, tap **Add file** → **Upload files**.
4. Upload `index.html`, `.nojekyll`, and the `assets` folder contents. Keep the folder structure exactly as shown.
5. Tap **Commit changes**.
6. Open repository **Settings** → **Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**.
8. Choose branch **main** and folder **/(root)**, then tap **Save**.
9. Wait for GitHub Pages to publish. Your site address will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/tdk-kitchen-cabinets/`

GitHub Pages free hosting requires a public repository on GitHub Free. The published website is public. GitHub says deployment can take up to about 10 minutes.

## Important limitations
- This is a static website. The enquiry and measurement forms open WhatsApp; they do not save submissions in a database.
- There is no public owner PIN or browser-only upload panel. To add photos or change text after publishing, upload/replace the files in the GitHub repository.
- Do not upload private customer details, passwords, or confidential files to the public repository.
